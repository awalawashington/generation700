<?php

return[
    'upload_disk' => 'public' //public or s3
];